const TIPO_ROJO = "Rojo";
const TIPO_COMBI = "Combi";

const Constantes = {
    TIPO_ROJO,
    TIPO_COMBI,
    TIPOS_UNIDAD: [TIPO_COMBI, TIPO_ROJO],
    PREFIJO_RUTAS: "rutas",
    PREFIJO_HORARIOS: "horarios",
};
export default Constantes;