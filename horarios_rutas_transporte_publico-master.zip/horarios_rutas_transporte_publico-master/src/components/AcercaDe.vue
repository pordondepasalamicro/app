<template>
  <v-card class="py-6 px-6" flat>
    <v-alert type="info">
      <h2>Acerca de</h2>
      <p>Creado y mantenido por <a class="text-button" href="https://parzibyte.me/blog">Parzibyte</a>.
        Código fuente disponible en <a href="https://parzibyte.me/blog">parzibyte.me/blog</a>
      </p>
      <h2>Créditos</h2>
      <p> Iconos diseñados por <a href="https://www.freepik.com" title="Freepik">Freepik</a> from <a
          href="https://www.flaticon.es/" title="Flaticon">www.flaticon.es</a>
      </p>
    </v-alert>


  </v-card>
</template>

<script>
export default {
  name: "AcercaDe"
}
</script>

<style scoped>
a {
  color: white !important;
}
</style>